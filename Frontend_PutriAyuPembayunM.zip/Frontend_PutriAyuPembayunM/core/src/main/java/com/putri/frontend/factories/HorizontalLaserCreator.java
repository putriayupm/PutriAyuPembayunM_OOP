package com.putri.frontend.factories;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;
import com.putri.frontend.obstacles.BaseObtacle;
import com.putri.frontend.obstacles.HorizontalLaser;
import com.putri.frontend.pools.HorizontalLaserPool;

import java.util.List;
import java.util.Random;

public class HorizontalLaserCreator implements ObstacleFactory.ObstacleCreator{
    private final HorizontalLaserPool pool = new HorizontalLaserPool();
    private static final float MIN_LENGTH = 100f;
    private static final float MAX_LENGTH = 300f;

    @Override
    public BaseObtacle create (float groundTopY, float spawnX, float playerHeight, Random rng){
        float length = rng.nextFloat() * (MAX_LENGTH - MIN_LENGTH) + MIN_LENGTH;
        float minY = groundTopY + playerHeight;
        float maxY = Gdx.graphics.getHeight() - playerHeight;
        float randomY = rng.nextFloat() * (maxY - minY) + minY;

        return pool.obtain(new Vector2(spawnX, randomY), (int)length);
    }

    @Override
    public void release(BaseObtacle obstacle) {
        if (obstacle instanceof HorizontalLaser) {
            pool.release((HorizontalLaser) obstacle);
        }
    }

    @Override
    public void releaseAll() {
        pool.releaseAll();
    }

    @Override
    public List<HorizontalLaser> getInUse() {
        return pool.getInUse();
    }

    @Override
    public boolean supports(BaseObtacle obstacle) {
        return obstacle instanceof HorizontalLaser;
    }

    @Override
    public String getName() {
        return "HorizontalLaser";
    }

}
